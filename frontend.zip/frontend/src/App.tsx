import React, { useMemo, useState } from 'react'
import { downloadLastMinutes } from './api'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

export default function App() {
  const [minutes, setMinutes] = useState(10)
  const audioSrc = useMemo(() => `${API_BASE}/live`, [])

  const onDownload = async () => {
    try {
      const file = await downloadLastMinutes(minutes)
      const url = URL.createObjectURL(file)
      const a = document.createElement('a')
      a.href = url
      a.download = `last-${minutes}-minutes.mp3`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } catch (e) {
      alert('Download failed. Ensure backend is running.')
      console.error(e)
    }
  }

  return (
    <div style={{ maxWidth: 720, margin: '2rem auto', padding: '0 1rem', fontFamily: 'system-ui, sans-serif' }}>
      <h1 style={{ marginBottom: '1rem' }}>Live Audio</h1>
      <audio controls autoPlay src={audioSrc} style={{ width: '100%' }} />

      <div style={{ marginTop: '1.5rem', display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
        <label>
          Minutes:
          <input
            type="number"
            min={1}
            max={30}
            value={minutes}
            onChange={(e) => setMinutes(Number(e.target.value))}
            style={{ marginLeft: 8, width: 80 }}
          />
        </label>
        <button onClick={onDownload}>
          Download last {minutes} minute{minutes === 1 ? '' : 's'}
        </button>
      </div>
    </div>
  )
}


