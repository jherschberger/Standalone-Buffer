const API_BASE = (import.meta as any).env?.VITE_API_BASE || 'http://localhost:8000'

export async function downloadLastMinutes(minutes: number): Promise<Blob> {
  const url = `${API_BASE}/download?minutes=${encodeURIComponent(minutes)}`
  const res = await fetch(url)
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`)
  }
  return await res.blob()
}


